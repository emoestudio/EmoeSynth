/* �ܽŶ��� */

#define LMX2572_SPI_CLK_PORT 		GPIOA
#define LMX2572_SPI_CLK_PIN  		GPIO_PIN_0

#define LMX2572_SPI_DATA_PORT  	GPIOA
#define LMX2572_SPI_DATA_PIN  	GPIO_PIN_1

#define LMX2572_SPI_READ_PORT  	GPIOB
#define LMX2572_SPI_READ_PIN  	GPIO_PIN_5

#define LMX2572_SPI_CS_PORT  		GPIOB
#define LMX2572_SPI_CS_PIN  		GPIO_PIN_4


#define LMX2572_SPI_CLK_LOW 		HAL_GPIO_WritePin(LMX2572_SPI_CLK_PORT, LMX2572_SPI_CLK_PIN, GPIO_PIN_RESET);
#define LMX2572_SPI_CLK_HIGH		HAL_GPIO_WritePin(LMX2572_SPI_CLK_PORT, LMX2572_SPI_CLK_PIN, GPIO_PIN_SET);

#define LMX2572_SPI_DATA_LOW 		HAL_GPIO_WritePin(LMX2572_SPI_DATA_PORT, LMX2572_SPI_DATA_PIN, GPIO_PIN_RESET);
#define LMX2572_SPI_DATA_HIGH		HAL_GPIO_WritePin(LMX2572_SPI_DATA_PORT, LMX2572_SPI_DATA_PIN, GPIO_PIN_SET);

#define LMX2572_SPI_DATA_READ 	HAL_GPIO_ReadPin(LMX2572_SPI_READ_PORT, LMX2572_SPI_READ_PIN)


#define LMX2572_SPI_CS_LOW			HAL_GPIO_WritePin(LMX2572_SPI_CS_PORT, LMX2572_SPI_CS_PIN, GPIO_PIN_RESET);
#define LMX2572_SPI_CS_HIGH			HAL_GPIO_WritePin(LMX2572_SPI_CS_PORT, LMX2572_SPI_CS_PIN, GPIO_PIN_SET);



/* �������� */
void LMX2572_GPIO_Init();
void LMX2572_WriteBus_1Byte(unsigned char dat);   // дһ���ֽ�
void LMX2572_WriteBus_2Byte(unsigned short dat);   // д�����ֽ�
void LMX2572_WriteReg(unsigned char Address, unsigned short Data);  // 

unsigned short LMX2572_ReadReg(unsigned char reg);

void LMX2572_ProgramReg_Default();
void LMX2572_Readback_Enable();
void LMX2572_Reset();
int LMX2572_SetFre(unsigned long long fre);