
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ADF4002_LMX2572_G431_BSPDriver' 
 * Target:  'ADF4002_LMX2572_G431_BSPDriver' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32g4xx.h"



#endif /* RTE_COMPONENTS_H */
